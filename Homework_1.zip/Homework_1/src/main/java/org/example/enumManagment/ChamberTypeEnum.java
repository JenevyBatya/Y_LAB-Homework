package org.example.enumManagment;

public enum ChamberTypeEnum {
    COWORKING,
    HALL;
}
