package org.example.managment;

public class GettingBackToMain extends Exception{
    public GettingBackToMain() {
    }
}
