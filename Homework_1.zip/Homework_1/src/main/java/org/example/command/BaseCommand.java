package org.example.command;

import org.example.managment.ResultResponse;

public interface BaseCommand {

    ResultResponse action();

}
